/** Automatically generated file. DO NOT MODIFY */
package yoo.app.kqxt;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}