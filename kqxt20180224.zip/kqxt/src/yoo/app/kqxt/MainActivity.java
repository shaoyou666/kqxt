package yoo.app.kqxt;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jsoup.Jsoup;

import com.baidu.appx.BDBannerAd;
import com.baidu.appx.BDInterstitialAd;
import com.baidu.appx.BDBannerAd.BannerAdListener;
import com.baidu.appx.BDInterstitialAd.InterstitialAdListener;
import com.baidu.autoupdatesdk.BDAutoUpdateSDK;
import com.baidu.autoupdatesdk.UICheckUpdateCallback;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class MainActivity extends Activity{
	
	private RelativeLayout appxBannerContainer;//�ٶȹ��
	private static BDBannerAd bannerAdView;//�ٶȹ��
	private BDInterstitialAd appxInterstitialAdView;//�ٶȹ��
	private static String TAG = "AppX_BannerAd";//�ٶȹ��
	private Net net;
	private Context mContext;
	private TextView tv_logininfo;
	private ListView lv_mainFuction;
	private List<Map<String,Object>> list_mainFuction;
	private MainAdapter adapter;
	private ProgressDialog dialog;
	private int ycCount = 0,dbCount = 0,spCount = 0;
	private String name,ope;
  

	@Override
	protected void onCreate(Bundle bundle){
		
	    super.onCreate(bundle);
	    //��title      
	    Log.i("MainActivity.onCreate", "MainActivity.onCreate");
	    requestWindowFeature(Window.FEATURE_NO_TITLE); 
	    setContentView(R.layout.main);
	    mContext = MainActivity.this;
	    list_mainFuction =  new ArrayList<Map<String, Object>>();
		adapter = new MainAdapter(mContext,list_mainFuction);
	    dialog = new ProgressDialog(mContext);
	    dialog.setIndeterminate(true);
	    dialog.show();
	    BDAutoUpdateSDK.uiUpdateAction(this, new MyUICheckUpdateCallback());
    
	    findView();
	    /*
	    if(updateThread == null){
	    	updateThread = new Thread(runnable);
	    	updateThread.start();
	    }*/
	    //�ٶȹ��///////////////////������///////////////////////////////////
	    // ���������ͼ
  	 		// ����ʱ��ʹ����ȷ��ApiKey�͹��λID
  	 		// �˴�ApiKey���ƹ�λID���ǲ����õ�
  	 		// ������ʽ�ύӦ�õ�ʱ����ȷ�ϴ������Ѿ�����Ϊ��Ӧ�ö�Ӧ��Key��ID
  	 		// �����ȡ��������ġ��ٶȿ��������Ľ��滻����Ʒ����.pdf��
  	 		bannerAdView = new BDBannerAd(this, "F1STqMpNgERCd7cOj3TBPzEc",
  	 				"Yxvaz6ZN62se5lHmp6rSovRR");
  	 		appxInterstitialAdView = new BDInterstitialAd(this,
   	 				"F1STqMpNgERCd7cOj3TBPzEc", "Tv4PMxcVVDs5SS3WPmNdxUGp");
  	 		// ���ú�����չʾ�ߴ磬�粻���ã�Ĭ��ΪSIZE_FLEXIBLE;
  			bannerAdView.setAdSize(BDBannerAd.SIZE_320X50);
  			// ���ú�������Ϊ������
  			bannerAdView.setAdListener(new BannerAdListener() {

  				@Override
  				public void onAdvertisementDataDidLoadFailure() {
  					Log.e(TAG, "load failure");
  				}

  				@Override
  				public void onAdvertisementDataDidLoadSuccess() {
  					Log.e(TAG, "load success");
  				}

  				@Override
  				public void onAdvertisementViewDidClick() {
  					Log.e(TAG, "on click");
  				}

  				@Override
  				public void onAdvertisementViewDidShow() {
  					Log.e(TAG, "on show");
  				}

  				@Override
  				public void onAdvertisementViewWillStartNewIntent() {
  					Log.e(TAG, "leave app");
  				}
  			});
  			// �����������
  			appxBannerContainer = (RelativeLayout) findViewById(R.id.appx_banner_container_main);

  			// ��ʾ�����ͼ
  			appxBannerContainer.addView(bannerAdView);
  			
  			appxInterstitialAdView.setAdListener(new InterstitialAdListener() {

   				@Override
   				public void onAdvertisementDataDidLoadFailure() {
   					Log.e(TAG, "load failure");
   				}

   				@Override
   				public void onAdvertisementDataDidLoadSuccess() {
   					Log.e(TAG, "load success");
   				}

   				@Override
   				public void onAdvertisementViewDidClick() {
   					Log.e(TAG, "on click");
   				}

   				@Override
   				public void onAdvertisementViewDidHide() {
   					Log.e(TAG, "on hide");
   				}

   				@Override
   				public void onAdvertisementViewDidShow() {
   					Log.e(TAG, "on show");
   				}

   				@Override
   				public void onAdvertisementViewWillStartNewIntent() {
   					Log.e(TAG, "leave");
   				}

   			});
   			appxInterstitialAdView.loadAd();
  	    
  		//�ٶȹ��//////////////////////////////////////////////////////
    
   
   	
    net = (Net)getApplication();
    net.showCookies();
	name = net.getCookieValue("rname");
	ope = net.getCookieValue("oper");
	Log.i("MainActivity.onCreate", "name="+name+";ope="+ope);
	String gb = net.getCookieValue("gb");
	if(gb==null){
		gb="δ����";
	}
	else if(gb.equals("gb")){
		gb = "����";
	}else{
		gb = "ֵ��";
	}
	tv_logininfo.setText("��ǰ�û���"+name+"�����Ϊ��"+gb);
	new GetData().execute(new String[0]);
    /*
   */
    
  }
  
  @Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
	    dialog.dismiss();
	  	super.onDestroy();
	  	net.addOperateRecord("MainActivity","onDestroy");
	  	//handler.removeCallbacks(runnable);
	}
  
  
  public void findView(){
	  tv_logininfo = (TextView)findViewById(R.id.tv_logininfo);
	  lv_mainFuction = (ListView)findViewById(R.id.list_main);
  }
  //�ٶȿ����߿�̨�Զ�����
  private class MyUICheckUpdateCallback implements UICheckUpdateCallback {

		@Override
		public void onCheckComplete() {
			dialog.dismiss();
		}

	}
  /*
  private Runnable runnable = new Runnable(){

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}
	  
  };
  private Handler handler = new Handler(){

	@Override
	public boolean sendMessageAtTime(Message msg, long uptimeMillis) {
		// TODO Auto-generated method stub
		return super.sendMessageAtTime(msg, uptimeMillis);
	}
	  
  };
  */
  class GetData extends AsyncTask<String, String, String>{
	  
	  private ProgressDialog dp = new ProgressDialog(mContext);
	  
		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			dp.setCancelable(false);
			dp.setTitle("��������");
			dp.setMessage("���ڼ���...");
			dp.show();
		}
		
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			dp.dismiss();
			
		    final String[] fucs;
		    final int[] dbNums;
		    if(ope.equals("A_hun") || ope.equals("B_nel")){
		    	String[] s = {"�򿨼�¼","�쳣����","��������","Ԥˢ����","��������","�˳���¼","����"};
		    	int[] n = {ycCount,dbCount,spCount,0,0,0,0};
		    	fucs = s;
		    	dbNums = n;
		    }else{
		    	String[] s = {"�򿨼�¼","�쳣����","Ԥˢ����","��������","�˳���¼","����"};
		    	int[] n = {ycCount,dbCount,0,0,0,0};
		    	fucs = s;
		    	dbNums = n;
		    }
		    for(int i=0;i<fucs.length;i++){
		    	Map<String,Object> map = new HashMap<String,Object>();
		    	map.put("title", fucs[i]);
		    	map.put("dbnum", dbNums[i]);
		    	list_mainFuction.add(map);
		    }
		    
		    
		    lv_mainFuction.setAdapter(adapter);
		    lv_mainFuction.setOnItemClickListener(new OnItemClickListener(){

				@Override
				public void onItemClick(AdapterView<?> parent, View view, int position,
						long id) {
					// TODO Auto-generated method stub
					Intent i;
					if(fucs[position].equals("�򿨼�¼")){
						i = new Intent(mContext,RecordActivity.class);
			    		startActivity(i);
					}else if(fucs[position].equals("Ԥˢ����")){
						i = new Intent(mContext,YssqActivity.class);
			    		startActivity(i);
					}else if(fucs[position].equals("�쳣����")){
						i = new Intent(mContext, TaskActivity.class);
			    		startActivity(i);
					}else if(fucs[position].equals("��������")){
						i = new Intent(mContext, SpTaskActivity.class);
			    		startActivity(i);
					}else if(fucs[position].equals("��������")){
						i = new Intent(mContext, MeActivity.class);
			    		startActivity(i);
					}else if(fucs[position].equals("�˳���¼")){
						SharedPreferences settings = getSharedPreferences("settings", Context.MODE_PRIVATE);
				    	Editor e = settings.edit();
				    	e.putBoolean("autologin", false);
				    	e.commit();
				    	i = new Intent(mContext, LoginActivity.class);
				      	startActivity(i); 	
				    	net.cleanCookie();
				    	finish();
					}else if(fucs[position].equals("�˳�Ӧ��")){
						new AlertDialog.Builder(mContext).setTitle("�Ƿ��˳���").setPositiveButton("ȷ��", new DialogInterface.OnClickListener()
				        {
				          @Override
						public void onClick(DialogInterface paramDialogInterface, int paramInt)
				          {
				        	  finish();
				            System.exit(0);
				          }
				        }).setNegativeButton("ȡ��", null).show();
					}else if(fucs[position].equals("����")){
						PackageManager pm = getPackageManager();
						String versionName = null;
						try {
							PackageInfo pi = pm.getPackageInfo(getPackageName(), 0);
							versionName = pi.versionName;
						} catch (NameNotFoundException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						new AlertDialog.Builder(mContext).setTitle("���ڿ���ϵͳapp-V"+versionName)
						.setMessage("    ��Ӧ�û�����β���Ź�˾����ϵͳ��ҳ����������������Թ�˾����ϵͳ��ҳ��Ϊ׼��\n    ��Ӧ�ð�Ȩ�����߸������У��Ǿ�����ͬ�ⲻ�ý�Ӧ�ý�����ҵ������\n\n    ���ߣ�Yooslin\n    ���ڣ�2016��10��\n").setPositiveButton("ȷ��", null).show();
					}
				}
		    	
		    });
		}
		
		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			/*******���쳣����****/
			//net.getInfo("MainActivity", "onCreate");
			String strYc = net.postURL(null, "http://119.146.208.70:1080/yicbck.asp");
			int ycSize = Jsoup.parse(strYc).select("tr").size();
			if(ycSize>2){
				ycCount = ycSize -2;
			}else{
				ycCount = 0;
			}
			/*******��ȡ���ڴ�������****/
			String strYcdb = net.postURL(null, "http://119.146.208.70:1080/dkyc_sp.asp");
			/*******��ȡ�ݼٴ�������****/
			String strXjdb = net.postURL(null, "http://119.146.208.70:1080/you.asp","utf-8");
			int dbSize = Jsoup.parse(strYcdb).select("tr").size();
			if(dbSize>2){
				dbCount = dbSize-2;
			}else{
				dbCount = 0;
			}
			int xjSize = Jsoup.parse(strXjdb).select("tr").size();
			int xjCount = 0;
			if(xjSize>2){
				xjCount = xjSize -2;
			}
			dbCount = dbCount+xjCount;
			if(ope.equals("A_hun") || ope.equals("B_nel")){
				String strycsp = net.postURL(null, "http://119.146.208.70:1080/yc_spdb.asp", "UTF-8");
				String strxjsp = net.postURL(null, "http://119.146.208.70:1080/xjsp_db.asp", "UTF-8");
				int ycspSize = Jsoup.parse(strycsp).select("tr").size();
				int xjspSize = Jsoup.parse(strxjsp).select("tr").size();
				if(ycspSize>3){
					ycspSize = ycspSize - 3;
				}else{
					ycspSize = 0;
				}
				if(xjspSize>3){
					xjspSize = xjspSize - 3;
				}else{
					xjspSize = 0;
				}
				spCount = ycspSize + xjspSize;
			}
			return null;
		}
	  
  }
  
  @Override
	protected void onRestart() {
		// TODO Auto-generated method stub
		super.onRestart();
		// ���ع��
		if (appxInterstitialAdView.isLoaded()) {
			int random = (int)(Math.random()*10 + 1);
			if(random == 5){
				appxInterstitialAdView.showAd();
			}
		} else {
			Log.i(TAG, "AppX Interstitial Ad is not ready");
			appxInterstitialAdView.loadAd();
		}
	}
  
}