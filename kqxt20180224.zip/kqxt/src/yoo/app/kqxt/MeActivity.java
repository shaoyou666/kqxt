package yoo.app.kqxt;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

public class MeActivity extends Activity {
	
	private ListView lv_peasonDetail,lv_lcxg;
	private EditText et_pw_used,et_pw_new,et_pw_new_confirm,et_newPhoneNum;
	private Button bt_changePw,bt_changePhoneNum;
	private Net net;
	private Context mContext;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.me);
		mContext = MeActivity.this;
		net = (Net)getApplication();
		//net.addOperateRecord("MeActivity","onCreate");
		findView();
		new GetData().execute(new String[0]);
		bt_changePw.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String p1 = et_pw_used.getText().toString();
				String p2 = et_pw_new.getText().toString();
				String p3 = et_pw_new_confirm.getText().toString();
				if(p1.equals("") || p2.equals("") || p3.equals("")){
					Toast.makeText(mContext, "�������벻�ܿ�!", Toast.LENGTH_SHORT).show();
				}else if(!p2.equals(p3)){
					Toast.makeText(mContext, "���������������ͬ��", Toast.LENGTH_SHORT).show();
				}else{
					new ChangePw().execute(new String[]{p1,p2,p3});
				}
			}
			
		});
		bt_changePhoneNum.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String newPhoneNum = et_newPhoneNum.getText().toString();
				if(newPhoneNum.equals("")){
					Toast.makeText(mContext, "�绰���벻�ܿգ�", Toast.LENGTH_SHORT).show();
				}else{
					new ChangePhoneNum().execute(new String[]{newPhoneNum});
				}
			}
			
		});
	}
	
	public void findView(){
		lv_peasonDetail = (ListView)findViewById(R.id.lv_peasonDetail);
		lv_lcxg = (ListView)findViewById(R.id.lv_lcxg);
		et_pw_used = (EditText)findViewById(R.id.et_pw_used);
		et_pw_new = (EditText)findViewById(R.id.et_pw_new);
		et_pw_new_confirm = (EditText)findViewById(R.id.et_pw_new_confirm);
		et_newPhoneNum = (EditText)findViewById(R.id.et_newPhoneNum);
		bt_changePw = (Button)findViewById(R.id.bt_changePw);
		bt_changePhoneNum = (Button)findViewById(R.id.bt_changePhoneNum);
		
	}
	class GetData extends AsyncTask<String, String, String[]>{
		private ProgressDialog pd;

		@Override
		protected String[] doInBackground(String... params) {
			// TODO Auto-generated method stub
			String r1 = net.postURL(null, "http://119.146.208.70:1080/grzlck.asp");
			String r2 = net.postURL(null, "http://119.146.208.70:1080/grxglcck.asp","UTF-8");
			return new String[]{r1,r2};
		}

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			pd = new ProgressDialog(mContext);
			pd.setTitle("��������");
			pd.setMessage("������...");
			pd.show();
		}

		@Override
		protected void onPostExecute(String[] result) {
			// TODO Auto-generated method stub
			pd.dismiss();
			Document doc1 = Jsoup.parse(result[0]);
			Elements ths1 = doc1.select("th");
			Elements tds1 = doc1.select("td");
			List<Map<String,Object>> list_p = new ArrayList<Map<String,Object>>();
			for(int i=0;i<tds1.size();i++){
				Map<String,Object> map_p = new HashMap<String,Object>();
				map_p.put("head", ths1.get(i+1).text().toString());
				map_p.put("detail", tds1.get(i).text().toString());
				list_p.add(map_p);
			}
			
			Document doc2 = Jsoup.parse(result[1]);
			Elements ths2 = doc2.select("th");
			Elements tds2 = doc2.select("td");
			List<Map<String,Object>> list_l = new ArrayList<Map<String,Object>>();
			for(int i=0;i<tds2.size();i++){
				Map<String,Object> map_l = new HashMap<String,Object>();
				map_l.put("head", ths2.get(i+1).text().toString());
				map_l.put("detail", tds2.get(i).text().toString());
				list_l.add(map_l);
			}
			
			SimpleAdapter a1 = new SimpleAdapter(mContext,list_p,R.layout.lv_detail,
					new String[]{"head","detail"},
					new int[]{R.id.tv_head,R.id.tv_detail});
			lv_peasonDetail.setAdapter(a1);
			SimpleAdapter a2 = new SimpleAdapter(mContext,list_l,R.layout.lv_detail,
					new String[]{"head","detail"},
					new int[]{R.id.tv_head,R.id.tv_detail});
			lv_lcxg.setAdapter(a2);
			
		}
	}
	class ChangePw extends AsyncTask<String, String, String>{

		private ProgressDialog pd;
		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			ArrayList<NameValuePair> postparams = new ArrayList<NameValuePair>();
	        postparams.add(new BasicNameValuePair("Password1", params[0]));
	        postparams.add(new BasicNameValuePair("Password2", params[1]));
	        postparams.add(new BasicNameValuePair("Password3", params[2]));
			String postresult = net.postURL(postparams, "http://119.146.208.70:1080/repwd.asp");
			return postresult;
		}

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			pd = new ProgressDialog(mContext);
			pd.setTitle("�޸�����");
			pd.setMessage("������...");
			pd.show();
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			pd.dismiss();
			String r = result.substring(result.indexOf("(\"")+2,result.indexOf("\")"));
			Toast.makeText(mContext, r, Toast.LENGTH_LONG).show();
			if(r.contains("�ɹ�")){
				et_pw_used.setText("");
				et_pw_new.setText("");
				et_pw_new_confirm.setText("");
			}
		}
		
	}
	
	class ChangePhoneNum extends AsyncTask<String, String, String>{
		private ProgressDialog pd;
		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			ArrayList<NameValuePair> postparams = new ArrayList<NameValuePair>();
	        postparams.add(new BasicNameValuePair("Text1", params[0]));
	        String postresult = net.postURL(postparams, "http://119.146.208.70:1080/xgdhcz.asp");
			return postresult;
		}

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			pd = new ProgressDialog(mContext);
			pd.setTitle("�޸�����");
			pd.setMessage("������...");
			pd.show();
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			pd.dismiss();
			String r = result.substring(result.indexOf("(\"")+2,result.indexOf("\")"));
			Toast.makeText(mContext, r, Toast.LENGTH_LONG).show();
			if(r.contains("�ɹ�")){
				et_newPhoneNum.setText("");
			}
		}
		
	}

}
