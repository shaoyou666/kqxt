package yoo.app.kqxt;

import java.util.List;
import java.util.Map;

import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SimpleAdapter;
import android.widget.TextView;

public class MSimpleAdapter extends SimpleAdapter {
	
	

	public MSimpleAdapter(Context context, List<Map<String, Object>> data,
			int resource, String[] from, int[] to) {
		super(context, data, resource, from, to);
		// TODO Auto-generated constructor stub
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return super.getCount();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return super.getItem(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return super.getItemId(position);
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		convertView = super.getView(position, convertView, parent);
		TextView tv_status = (TextView)convertView.findViewById(R.id.tv_status);
		String s = tv_status.getText().toString();
		if(s.contains("�쳣")){
			tv_status.setTextColor(Color.RED);
		}else if(s.contains("����")){
			tv_status.setTextColor(Color.BLUE);
		}else if(s.contains("�ٵ�") || s.contains("����")){
			tv_status.setTextColor(Color.MAGENTA);
		}else
			tv_status.setTextColor(Color.BLACK);
		return convertView;
	}
	

}
