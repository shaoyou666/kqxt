package yoo.app.kqxt;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.IBinder;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.http.NameValuePair;
import org.apache.http.cookie.Cookie;
import org.apache.http.message.BasicNameValuePair;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import com.baidu.appx.BDBannerAd;
import com.baidu.appx.BDInterstitialAd;
import com.baidu.appx.BDBannerAd.BannerAdListener;
import com.baidu.appx.BDInterstitialAd.InterstitialAdListener;
import com.baidu.autoupdatesdk.BDAutoUpdateSDK;
import com.baidu.autoupdatesdk.UICheckUpdateCallback;

public class LoginActivity extends Activity{
	
	private RelativeLayout appxBannerContainer;//�ٶȹ��
	private static BDBannerAd bannerAdView;//�ٶȹ��
	private BDInterstitialAd appxInterstitialAdView;//�ٶȹ��
	private static String TAG = "AppX_BannerAd";//�ٶȹ��
	
	  public static String homeURL = "http://119.146.208.70:1080/";
	  public static String MEID,IMEI,versionName,versionCode,osVersion,phoneModel,location,other;
	  private Button bt_login;
	  public Cookie cookies;
	  private EditText et_password;
	  private EditText et_username;
	  private EditText et_verifyCode;
	  private EditText et_log;
	  private ImageView iv_verifyCode;
	  //private CheckBox cb_autologin;
	  private boolean isAutoLogin;
	  private Context mContext;
	  private Net net;
	  private TextView tv_forgetPw;
	  private ProgressDialog pd;
	  private SharedPreferences settings;
	  private String username,password,hash,verifyCode;
	  private ProgressDialog dialog;
	
	  public void findView(){
		  et_username = ((EditText)findViewById(R.id.et_username));
		  et_password = ((EditText)findViewById(R.id.et_password));
		  et_verifyCode = (EditText)findViewById(R.id.et_verifyCode);
		  et_log = (EditText)findViewById(R.id.et_log);
		  iv_verifyCode = (ImageView)findViewById(R.id.im_verifyCode);
		  bt_login = (Button)findViewById(R.id.bt_login);
		  tv_forgetPw = (TextView)findViewById(R.id.tv_forgetPw);
		  et_verifyCode.requestFocus();
		  //cb_autologin = (CheckBox)findViewById(R.id.cb_isAutoLogin);
	  }
	//�ٶȿ����߿�̨�Զ�����
	  private class MyUICheckUpdateCallback implements UICheckUpdateCallback {

			@Override
			public void onCheckComplete() {
				dialog.dismiss();
			}

		}
	  protected void onDestroy() {
			// TODO Auto-generated method stub
		    dialog.dismiss();
		  	super.onDestroy();
		  	net.addOperateRecord("MainActivity","onDestroy");
		  	//handler.removeCallbacks(runnable);
		}

	  
	  
	  @Override
	protected void onCreate(Bundle bundle)
	  {
	    super.onCreate(bundle);
	    //��title      
	    requestWindowFeature(Window.FEATURE_NO_TITLE); 

	    //�Զ������
	    //requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
	    mContext = LoginActivity.this;
	    setContentView(R.layout.login);
	    pd = new ProgressDialog(mContext);
	    //���ñ���Ϊĳ��layout
	    //getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.titlebar);
	    findView();
	    dialog = new ProgressDialog(mContext);
	    dialog.setIndeterminate(true);
	    dialog.show();
	    BDAutoUpdateSDK.uiUpdateAction(this, new MyUICheckUpdateCallback());
	    //�ٶȹ��//////////////������////////////////////////////////////////
	    // ���������ͼ
	 		// ����ʱ��ʹ����ȷ��ApiKey�͹��λID
	 		// �˴�ApiKey���ƹ�λID���ǲ����õ�
	 		// ������ʽ�ύӦ�õ�ʱ����ȷ�ϴ������Ѿ�����Ϊ��Ӧ�ö�Ӧ��Key��ID
	 		// �����ȡ��������ġ��ٶȿ��������Ľ��滻����Ʒ����.pdf��
	 		bannerAdView = new BDBannerAd(this, "F1STqMpNgERCd7cOj3TBPzEc",
	 				"Yxvaz6ZN62se5lHmp6rSovRR");
	 		appxInterstitialAdView = new BDInterstitialAd(this,
   	 				"F1STqMpNgERCd7cOj3TBPzEc", "Tv4PMxcVVDs5SS3WPmNdxUGp");
	 	// ���ú�����չʾ�ߴ磬�粻���ã�Ĭ��ΪSIZE_FLEXIBLE;
			bannerAdView.setAdSize(BDBannerAd.SIZE_320X50);
			// ���ú�������Ϊ������
			bannerAdView.setAdListener(new BannerAdListener() {

				@Override
				public void onAdvertisementDataDidLoadFailure() {
					Log.e(TAG, "load failure");
				}

				@Override
				public void onAdvertisementDataDidLoadSuccess() {
					Log.e(TAG, "load success");
				}

				@Override
				public void onAdvertisementViewDidClick() {
					Log.e(TAG, "on click");
				}

				@Override
				public void onAdvertisementViewDidShow() {
					Log.e(TAG, "on show");
				}

				@Override
				public void onAdvertisementViewWillStartNewIntent() {
					Log.e(TAG, "leave app");
				}
			});
			// �����������
			appxBannerContainer = (RelativeLayout) findViewById(R.id.appx_banner_container);

			// ��ʾ�����ͼ
			appxBannerContainer.addView(bannerAdView);
	    
			appxInterstitialAdView.setAdListener(new InterstitialAdListener() {

   				@Override
   				public void onAdvertisementDataDidLoadFailure() {
   					Log.e(TAG, "load failure");
   				}

   				@Override
   				public void onAdvertisementDataDidLoadSuccess() {
   					Log.e(TAG, "load success");
   				}

   				@Override
   				public void onAdvertisementViewDidClick() {
   					Log.e(TAG, "on click");
   				}

   				@Override
   				public void onAdvertisementViewDidHide() {
   					Log.e(TAG, "on hide");
   				}

   				@Override
   				public void onAdvertisementViewDidShow() {
   					Log.e(TAG, "on show");
   				}

   				@Override
   				public void onAdvertisementViewWillStartNewIntent() {
   					Log.e(TAG, "leave");
   				}

   			});
   			appxInterstitialAdView.loadAd();
		//�ٶȹ��//////////////////////////////////////////////////////
	    
	    net = (Net)getApplication();
	    
	    settings = getSharedPreferences("settings", Context.MODE_PRIVATE); 
	    username = settings.getString("username", null);
	    password = settings.getString("password", null);
	    //isAutoLogin = settings.getBoolean("autologin", false);
	    if(username != null){
	    	et_username.setText(username);
	    }
	    if(password != null){
	    	et_password.setText(password);
	    }
	    //cb_autologin.setChecked(isAutoLogin);
	    //if(isAutoLogin){
	    //	login();
	    //}
	    new GetData().execute(new String[0]);
	    new GetVerify().execute(new String[0]);
	    
	    iv_verifyCode.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				new GetVerify().execute(new String[0]);
			}
        	
        });
	    
	    bt_login.setOnClickListener(new OnClickListener()
	    {
	      @Override
		public void onClick(View paramView)
	      {
	    	  login();	        
	      }
	    });
	    tv_forgetPw.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				final EditText et_forgetUsername = new EditText(mContext);
				et_forgetUsername.setInputType(InputType.TYPE_CLASS_NUMBER);
				et_forgetUsername.setHint("�����ֻ�����");
				new AlertDialog.Builder(mContext)
				.setTitle("��������")
				.setView(et_forgetUsername)
				.setPositiveButton("��������", new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						final String str = et_forgetUsername.getText().toString();
						new AlertDialog.Builder(mContext).setTitle("ȷ����������")
						.setMessage("�Ƿ�ȷ�Ͻ��û�"+str+"���������ã����óɹ������������뵽���ֻ��ϣ�")
						.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
							
							@Override
							public void onClick(DialogInterface dialog, int which) {
								// TODO Auto-generated method stub
								new ResetPw().execute(new String[]{str});
							}
						}).setNegativeButton("ȡ��", null).show();
						
						
					}
				}).setNegativeButton("ȡ��", null).show();
			}
	    	
	    });
	  }
	  
	  public String hex_md5(String s){
		  try {
			MessageDigest digest = MessageDigest.getInstance("MD5");
			digest.update(s.getBytes("UTF-8"));
			String hex = new BigInteger(1, digest.digest()).toString(16);  
	        // ����BigIntegerʡ�Ե�ǰ��0  
	        return new String(new char[32 - hex.length()]).replace("\0", "0") + hex; 
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	  }
	  
	  public void login(){
		  username = et_username.getText().toString();
		  password = et_password.getText().toString();
		  verifyCode = et_verifyCode.getText().toString();
		  String password_md5 = hex_md5(password+hash);
		  //Toast.makeText(mContext, "username:"+username+"\npassword:"+password+"\nhash:"+hash+"\nverifyCode:"+verifyCode+"\nhex_md5:"+password_md5, Toast.LENGTH_LONG).show();
		  //isAutoLogin = cb_autologin.isChecked();
		  Editor editor = settings.edit();
		  editor.putString("username", username);
		  editor.putString("password", password);
		  //editor.putBoolean("autologin", isAutoLogin);
		  editor.commit();
		  String[] postParams ={username,password_md5,verifyCode,hash};
		  hideSoftInput(bt_login.getWindowToken());
		  LoginSys loginsys = new LoginSys();
		  loginsys.execute(postParams);
	  }
	  
	class LoginSys extends AsyncTask<String, String, String>{

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			
			if(params[0].equals("") || params[1].equals("") || params[0] == null || params[1] == null)
				return null;
			ArrayList<NameValuePair> postparams = new ArrayList<NameValuePair>();
	        postparams.add(new BasicNameValuePair("m1", params[0]));
	        postparams.add(new BasicNameValuePair("p1", params[1]));
	        postparams.add(new BasicNameValuePair("txt_check", params[2]));
	        postparams.add(new BasicNameValuePair("hash", params[3]));
	        //String result = net.postURL(postparams, homeURL + "pw_chk.asp", "UTF-8");
	        //String result = net.postURL(postparams, homeURL);
	        //Document doc = Jsoup.parse(result);
	        //String hash = doc.select("input").get(0).val();
	        //String hash = doc.select("input[hash]").val();
	        //Log.i("LoginActivity",hash);
	        //postparams.add(new BasicNameValuePair("hash", hash));
	        
	        String result = net.postURL(postparams, homeURL + "pw_chk.asp","utf-8");
	        /*��¼�ɹ����ռ��豸��Ϣ
	        if ((result != null) && !result.contains("alert")){
	        	//result = net.postURL(postparams, homeURL + "atv.asp");
	        	net.getInfo("LoginActivity", "LoginSys,"+params[0]+","+params[1]);
	        }else{
	        	net.getInfo("LoginActivity", "LoginSys,"+params[0]+",wrong password");
	        }
	        */
			return result;
		}

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			pd.setCancelable(false);
			pd.setTitle("��¼ϵͳ");
			pd.setMessage("���ڵ�¼�����Ժ󡣡���");
			pd.show();
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			//super.onPostExecute(result);
			pd.dismiss();
			
			if(result.equals("NotNet")){
				Toast.makeText(mContext, "���粻���û���ϵͳ�����������ã���", Toast.LENGTH_SHORT).show();
			}/*else if ((result == null) || result.contains("alert")){
				Toast.makeText(mContext, "��½ʧ�ܣ������û��������룡", Toast.LENGTH_SHORT).show();
			}*/else if(result.contains("index.asp") || result.contains("��ӭ")){
				Log.i("LoginActivity", "��¼�ɹ���");
	        	Intent intent = new Intent(mContext, MainActivity.class);
	        	startActivity(intent); 	
	        	finish();
			}else{
				et_log.setVisibility(View.VISIBLE);
				et_log.setText(result);
			}
			/* 
			if(result.equals("NotNet")){
				Toast.makeText(mContext, "���粻���û���ϵͳ�����������ã���", Toast.LENGTH_SHORT).show();
			}else if ((result != null) && !result.contains("alert")){
				Log.i("LoginActivity", "��¼�ɹ���");
	        	Intent intent = new Intent(mContext, MainActivity.class);
	        	startActivity(intent); 	
	        	finish();
	        }
	        else{
	          Toast.makeText(mContext, "��½ʧ�ܣ������û��������룡", Toast.LENGTH_SHORT).show();
	        }
	       */
		}
	  
	}
	
	class ResetPw extends AsyncTask<String, String, String>{

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			
			pd.setTitle("��������");
			pd.setMessage("�����ύ���롣����");
			pd.show();
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			pd.dismiss();
			if(result.contains("���͵����ʺ�"))
				Toast.makeText(mContext, "���뽫��2�����ڷ��͵����ʺŶ�Ӧ�ֻ������ϡ�", Toast.LENGTH_LONG).show();
			else
				Toast.makeText(mContext, "��������˺Ų����ڣ������˺ŵ���ȷ�ԡ�", Toast.LENGTH_LONG).show();
		}

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			ArrayList<NameValuePair> postparams = new ArrayList<NameValuePair>();
	        postparams.add(new BasicNameValuePair("bianh", params[0]));
	        String result = net.postURL(postparams, homeURL + "wjmm_wc.asp", "gb2312");
			return result;
		}
		
	}
	
	//���ؼ���
	private void hideSoftInput(IBinder token) {  
		if (token != null) {  
			InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);  
			im.hideSoftInputFromWindow(token,  
			InputMethodManager.HIDE_NOT_ALWAYS);  
		}  
	}

	@Override
	protected void onRestart() {
		// TODO Auto-generated method stub
		super.onRestart();
		// ���ع��
		if (appxInterstitialAdView.isLoaded()) {
			appxInterstitialAdView.showAd();
		} else {
			Log.i(TAG, "AppX Interstitial Ad is not ready");
			appxInterstitialAdView.loadAd();
		}
	}

	
	//��ȡ��¼ҳ��Ϣ
	class GetData extends AsyncTask<String, String, String>{
		  
		 
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			hash = Jsoup.parse(result).select("input").get(1).val();
		}
		
		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			String strLogin = net.postURL(null, "http://119.146.208.70:1080/logn.asp");
			
			return strLogin;
		}
		  
	 }

	class GetVerify extends AsyncTask<String, String, Bitmap>{//��ȡ��֤��

		@Override
		protected Bitmap doInBackground(String... params) {
			// TODO Auto-generated method stub
			Long time = new Date().getTime();
			String timeStr = time.toString();
			return net.getVerifyCode("http://119.146.208.70:1080/yzm.asp?" + timeStr);
			//return getVerifyImg("http://www.zhuanpaopao.com/welcome/verifyCode?"+Math.random());
		}

		@Override
		protected void onPostExecute(Bitmap result) {
			// TODO Auto-generated method stub
			iv_verifyCode.setImageBitmap(result);
		}
    	
    }
	  
}