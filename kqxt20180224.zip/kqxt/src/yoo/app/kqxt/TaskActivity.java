package yoo.app.kqxt;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.SimpleAdapter;


public class TaskActivity extends Activity {

	private ListView lv_taskRecord,lv_xjdb;
	private List<Map<String,Object>> list_task,list_xjdb;
	private SimpleAdapter adapter_task;
	private SimpleAdapter adapter_xjdb;
	private ProgressDialog pd;
	private Context mContext;
	private Net net;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		//��title      
	    requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.task);
		mContext = TaskActivity.this;
		pd = new ProgressDialog(mContext);
		net = (Net)getApplication();
		//net.addOperateRecord("TaskActivity","onCreate");
		lv_taskRecord = (ListView)findViewById(R.id.lv_taskRecord);
		lv_xjdb = (ListView)findViewById(R.id.lv_xjdb);
		list_task = new ArrayList<Map<String,Object>>();
		list_xjdb = new ArrayList<Map<String,Object>>();
		GetListData getListData = new GetListData();
		getListData.execute(new String[0]);
		
		lv_taskRecord.setOnItemClickListener(new OnItemClickListener(){

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				//ViewHolder holder = (ViewHolder)view.getTag();
				//holder.cb.toggle();
				//TaskAdapter.getIsSelected().put(position, holder.cb.isChecked());
				
				
				
				
				String u = "http://119.146.208.70:1080/"+list_task.get(position).get("ycdb_url").toString();
				new GetDbDetail().execute(new String[]{u,position+""});
			}
			
		});
		
		lv_xjdb.setOnItemClickListener(new OnItemClickListener(){

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				String u = "http://119.146.208.70:1080/"+list_xjdb.get(position).get("xjdb_url").toString();
				new GetXjDbDetail().execute(new String[]{u,position+""});
			}
			
		});
	}

	
	public class GetListData extends AsyncTask<String, String, String[]>{

		@Override
		protected String[] doInBackground(String... params) {
			// TODO Auto-generated method stub
			
			/*******��ȡ���ڴ�������****/
			String strYcdb = net.postURL(null, "http://119.146.208.70:1080/dkyc_sp.asp");
			
			/*******��ȡ�ݼٴ�������****/
			String strXjdb = net.postURL(null, "http://119.146.208.70:1080/you.asp","utf-8");

			return new String[] {strYcdb,strXjdb};
		}

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			pd.setTitle("��ѯ�����¼");
			pd.setMessage("���ݼ����У����Ժ󡣡���");
			pd.show();
		}

		@Override
		protected void onPostExecute(String[] result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			//list_unNormal.clear();
			list_task.clear();
			list_xjdb.clear();
			Map<String, Object> map;
			
			Document doc_ycdb = Jsoup.parse(result[0]);
			Elements trs_ycdb = doc_ycdb.select("tr");
			
			if(trs_ycdb.size()>2){
				/**/
				for(int i=2;i<trs_ycdb.size();i++){
					Elements tds = trs_ycdb.get(i).select("td");
					if(tds.size()>1 && tds != null){
						map = new HashMap<String, Object>();
						String dblx = tds.get(0).text().trim();
						String ycdb_url = tds.get(1).select("a").attr("href").trim();
						map.put("dblx", dblx);
						map.put("ycdb_url", ycdb_url);
						list_task.add(map);
					}					
				}
			}
			
			
			Document doc_xjdb = Jsoup.parse(result[1]);
			Elements trs_xjdb = doc_xjdb.select("tr");
			
			if(trs_xjdb.size()>2){
				/**/
				for(int i=2;i<trs_xjdb.size();i++){
					Elements tds = trs_xjdb.get(i).select("td");
					if(tds.size()>1 && tds != null){
						map = new HashMap<String, Object>();
						String dblx = tds.get(0).text().trim();
						String xjdb_url = tds.get(1).select("a").attr("href").trim();
						map.put("dblx", dblx);
						map.put("xjdb_url", xjdb_url);
						list_xjdb.add(map);
					}
				}
			}
			
			
			adapter_task = new SimpleAdapter(mContext,list_task,R.layout.lv_simple,
					new String[]{"dblx"},
					new int[]{R.id.text1});
			lv_taskRecord.setAdapter(adapter_task);
			adapter_xjdb = new SimpleAdapter(mContext,list_xjdb,R.layout.lv_simple,
					new String[]{"dblx"},
					new int[]{R.id.text1});
			lv_xjdb.setAdapter(adapter_xjdb);
			
			pd.dismiss();
		}
		
	}
	
	
	public class GetDbDetail extends AsyncTask<String, String, String>{
		private String url = null;
		private String url_delete = null;
		private boolean canDelete = false;
		private int position;

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			pd.setTitle("��������");
			pd.setMessage("��ѯ��...");
			pd.show();
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			pd.dismiss();
			if(canDelete){
				new AlertDialog.Builder(mContext).setMessage(result)
				.setPositiveButton("ɾ������", new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						String postU = "http://119.146.208.70:1080/"+url_delete;
						new PostGd().execute(new String[]{postU});
						list_task.remove(position);
						adapter_task.notifyDataSetChanged();
					}
				}).setNegativeButton("����", null).show();
			}
			else if(url == null){
				new AlertDialog.Builder(mContext).setMessage(result)
				.setPositiveButton("ȷ��", null).show();
			}else{
				new AlertDialog.Builder(mContext).setMessage(result)
				.setPositiveButton("ȷ�Ϲ鵵", new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						String postU = "http://119.146.208.70:1080/"+url;
						new PostGd().execute(new String[]{postU});
						list_task.remove(position);
						adapter_task.notifyDataSetChanged();
					}
				}).show();
			}
			
		}
		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			Document doc = Jsoup.parse(net.postURL(null, params[0]));
			Elements trs = doc.select("tr");
			String result = null;
			if(trs.size()>4){
				String kind = trs.get(3).select("td").get(0).text().trim();
				String date = trs.get(4).select("td").get(0).text().trim();
				String bc = trs.get(4).select("td").get(1).text().trim();
				String status = trs.get(5).select("td").get(0).text().trim();
				String atlast = "";
				for(int i=5;i<trs.size();i++){
					Elements ths = trs.get(i).select("th");
					if(ths.size()>0){						
						String th = ths.get(0).text().trim();
						if(th.contains("���뵥���")){
							atlast = trs.get(i).select("td").get(0).text().trim();
							atlast = atlast.replace("&nbsp;", "");
							Log.i("GetDbDetail", "Geted");
							break;
						}
					}
				}
				if(atlast.equals("")){
					result = "�쳣��Σ�"+date+bc+"\n\n�쳣ԭ��"+kind+"\n\n���뵥���̣�"+status;
				}else{
					result = "�쳣��Σ�"+date+bc+"\n\n�쳣ԭ��"+kind+"\n\n���뵥���̣�"+status+"\n\n���뵥�����"+atlast;
				}
			}
			Elements as = doc.select("a");
			for(int i=0;i<as.size();i++){
				String str = as.get(i).text().trim();
				if(str.contains("ɾ��")){
					canDelete = true;
					url_delete = as.get(i).attr("href").trim();
				}else if(str.contains("ȷ��")){
					url = as.get(i).attr("href").trim();
				}
			}
			
			position = Integer.parseInt(params[1]);
			return result;
		}
		
	}
	
	public class GetXjDbDetail extends AsyncTask<String, String, String>{
		
		private String url = null;
		private String url_delete = null;
		private boolean canDelete = false;
		private int position;

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			pd.setTitle("��������");
			pd.setMessage("��ѯ��...");
			pd.show();
			
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			pd.dismiss();
			if(canDelete){
				new AlertDialog.Builder(mContext).setMessage(result)
				.setPositiveButton("ɾ������", new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						String postU = "http://119.146.208.70:1080/"+url_delete;
						new PostGd().execute(new String[]{postU});
						list_xjdb.remove(position);
						adapter_xjdb.notifyDataSetChanged();
						
					}
				}).setNegativeButton("����", null).show();
			}
			else if(url == null){
				new AlertDialog.Builder(mContext).setMessage(result)
				.setPositiveButton("ȷ��", null).show();
			}else{
				new AlertDialog.Builder(mContext).setMessage(result)
				.setPositiveButton("ȷ�Ϲ鵵", new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						String postU = "http://119.146.208.70:1080/"+url;
						new PostGd().execute(new String[]{postU});
						list_xjdb.remove(position);
						adapter_xjdb.notifyDataSetChanged();
					}
				}).show();
			}
		}

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			Document doc = Jsoup.parse(net.postURL(null, params[0]));
			Elements trs = doc.select("tr");
			String result = null;
			if(trs.size()>4){
				String kind = trs.get(3).select("td").get(0).text().trim();
				String sdate = trs.get(4).select("td").get(1).text().trim();
				String edate = trs.get(5).select("td").get(1).text().trim();
				String status = trs.get(6).select("td").get(0).text().trim();
				String atlast = "";
				for(int i=5;i<trs.size();i++){
					Elements ths = trs.get(i).select("th");
					if(ths.size()>0){
						String th =ths.get(0).text().trim();
						if(th.contains("���뵥���")){
							atlast = trs.get(i).select("td").get(0).text().trim();
							atlast = atlast.replace("&nbsp;", "");
							break;
						}
					}
					
				}
				if(atlast.equals("")){
					result = "�ݼ�ʱ�䣺"+sdate+"��"+edate+"\n\n�ݼ�ԭ��"+kind+"\n\n���뵥���̣�"+status;
				}else{
					result = "�ݼ�ʱ�䣺"+sdate+"��"+edate+"\n\n�ݼ�ԭ��"+kind+"\n\n���뵥���̣�"+status+"\n\n���뵥�����"+atlast;
				}
			}
			Elements as = doc.select("a");
			for(int i=0;i<as.size();i++){
				String str = as.get(i).text().trim();
				if(str.contains("ɾ��")){
					canDelete = true;
					url_delete = as.get(i).attr("href").trim();
				}else if(str.contains("ȷ��")){
					url = as.get(i).attr("href").trim();
				}
			}
			position = Integer.parseInt(params[1]);
			return result;
		}
		
	}
	
	public class PostGd extends AsyncTask<String, String, String>{

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			net.postURL(null, params[0]);
			return null;
		}
		
	}
}
