package yoo.app.kqxt;

import android.app.Application;
import org.apache.http.client.CookieStore;

public class Cookies extends Application
{
  private CookieStore cookies;

  public CookieStore getCookie()
  {
    return this.cookies;
  }

  public void setCookie(CookieStore paramCookieStore)
  {
    this.cookies = paramCookieStore;
  }
}