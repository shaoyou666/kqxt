package yoo.app.kqxt;

import java.util.List;
import java.util.Map;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class MainAdapter extends BaseAdapter {
	
	private List<Map<String,Object>> list;
	private LayoutInflater inflater = null;
	
	public MainAdapter(Context context, List<Map<String,Object>> list){
		this.list = list;
		inflater = LayoutInflater.from(context);
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolder holder = null;
		if(convertView == null){
			holder = new ViewHolder();
			convertView = inflater.inflate(R.layout.lv_main, parent, false);
			holder.tv_fuc = (TextView) convertView.findViewById(R.id.tv_fuction);
			holder.tv_num = (TextView) convertView.findViewById(R.id.tv_dbNum);
			convertView.setTag(holder);
		}else{
			holder = (ViewHolder) convertView.getTag();
		}
		String strFuc = list.get(position).get("title").toString();
		String strDbNum = list.get(position).get("dbnum").toString();
		holder.tv_fuc.setText(strFuc);
		int dbNum = Integer.parseInt(strDbNum);
		if(dbNum == 0){
			holder.tv_num.setVisibility(View.GONE);
		}else{
			holder.tv_num.setVisibility(View.VISIBLE);
			if(holder.tv_fuc.getText().toString().contains("����")){
				holder.tv_num.setText(strDbNum+"������");
			}else{
				holder.tv_num.setText(strDbNum+"���쳣");
			}
			
		}
		return convertView;
	}
	
	public static class ViewHolder{
		private TextView tv_fuc;
		private TextView tv_num;
	}

}
