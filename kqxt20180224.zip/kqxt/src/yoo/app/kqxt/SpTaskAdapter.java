package yoo.app.kqxt;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class SpTaskAdapter extends BaseAdapter {
	
	private List<Map<String,Object>> list;
	private static HashMap<Integer,Boolean> isSelected;
	private Context mContext;
	private ListView listview;
	private LayoutInflater inflater = null;

	public SpTaskAdapter(Context context, List<Map<String,Object>> list, ListView listview){
		this.list = list;
		mContext = context;
		this.listview = listview;
		inflater = LayoutInflater.from(context);
		isSelected = new HashMap<Integer, Boolean>();
		for(int i=0;i<list.size();i++){
			getIsSelected().put(i, false);
		}
	}
	
	public static HashMap<Integer, Boolean> getIsSelected(){
		return isSelected;
	}
	
	public static void setIsSelected(HashMap<Integer, Boolean> isSelected){  
		SpTaskAdapter.isSelected = isSelected;
    }  
	
	 public static class ViewHolder {
	        TextView tv_id,tv_name,tv_sp,tv_reason,tv_url;
	 }  
	 
	
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public boolean hasStableIds() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolder holder = null;
		if(convertView == null){
			holder = new ViewHolder();
			convertView = inflater.inflate(R.layout.lv_sptask, parent, false);
			holder.tv_id = (TextView)convertView.findViewById(R.id.tv_sp_id);
			holder.tv_name = (TextView)convertView.findViewById(R.id.tv_sp_name);
			holder.tv_sp = (TextView)convertView.findViewById(R.id.tv_sp_sp);
			holder.tv_reason = (TextView)convertView.findViewById(R.id.tv_sp_reason);
			holder.tv_url = (TextView)convertView.findViewById(R.id.tv_sp_url);
			convertView.setTag(holder);
		}else{
			holder = (ViewHolder)convertView.getTag();
		}
		holder.tv_id.setText(list.get(position).get("sp_id").toString());
		holder.tv_name.setText(list.get(position).get("sp_name").toString());
		holder.tv_sp.setText(list.get(position).get("sp_sp").toString());
		holder.tv_reason.setText(list.get(position).get("sp_reason").toString());
		holder.tv_url.setText(list.get(position).get("sp_url").toString());
		updateBackground(position , convertView);
		return convertView;
	}

	public void updateBackground(int position, View convertView) {
		// TODO Auto-generated method stub
		int backgroundId;
		if (listview.isItemChecked(position)) {
			backgroundId = R.drawable.abc_list_pressed_holo_light;
		} else {
			backgroundId = R.drawable.abc_list_selector_holo_dark;
		}
		Drawable background = mContext.getResources().getDrawable(backgroundId);
		convertView.setBackground(background);
	}

}
