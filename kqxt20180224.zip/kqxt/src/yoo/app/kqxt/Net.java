package yoo.app.kqxt;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.CookieStore;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.HttpHostConnectException;
import org.apache.http.cookie.Cookie;
import org.apache.http.impl.client.AbstractHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.params.HttpParams;

import android.app.Application;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Build;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Log;

public class Net extends Application {
	
	private  String android_id,MEID,IMEI,IMSI,versionName,versionCode,osVersion,phoneModel,location,other,activityName,operation;
	
	private static HttpClient httpClient = null;
	private CookieStore cookies;
	
	private static synchronized HttpClient getHttpClient(){
		if(httpClient == null){
			final HttpParams httpParams = new BasicHttpParams();
			httpParams.setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, 5000);//����ʱ��2��
			httpParams.setParameter(CoreConnectionPNames.SO_TIMEOUT, 10000);//����ʱ��2��
			httpClient = new DefaultHttpClient(httpParams);
		}
		return httpClient;
	}
	
	public CookieStore getCookie(){
		return this.cookies;
	}
	public void setCookie(CookieStore paramCookieStore){
		this.cookies = paramCookieStore;
	}
	
	@SuppressWarnings("deprecation")
	public String getCookieValue(String params){
		List<Cookie> cookie = cookies.getCookies();
		for(int i=0 ;i<cookie.size();i++){
			if(cookie.get(i).getName().equals(params)){
				return URLDecoder.decode(cookie.get(i).getValue());
			}
		}
		return null;
	}
	@SuppressWarnings("deprecation")
	public void showCookies(){
		List<Cookie> cookie = cookies.getCookies();
		for(int i=0 ;i<cookie.size();i++){
			Log.i("cookie", cookie.get(i).getName()+"="+URLDecoder.decode(cookie.get(i).getValue()));
		}
	}
	public void cleanCookie(){
		cookies = null;
	}
	
	public String postURL(ArrayList<NameValuePair> params, String url){
		return postURL(params,url,"gb2312");
	}
	
	public String postURL(ArrayList<NameValuePair> params, String url, String charsetName){
		Log.i("Net.postURL.url", url);
		
		String result = "";
		BufferedReader reader = null;
		try {
			HttpClient  client = getHttpClient();
			HttpPost httpPost = new HttpPost(url);
			if(params != null)
				httpPost.setEntity(new UrlEncodedFormEntity(params,charsetName));
			
			((AbstractHttpClient)client).setCookieStore(cookies);

			HttpResponse response = client.execute(httpPost);
			if(response.getStatusLine().getStatusCode() == HttpStatus.SC_OK){
				HttpEntity entity  = response.getEntity();
				cookies = ((AbstractHttpClient)client).getCookieStore();
				InputStream is = entity.getContent();
				reader = new BufferedReader(new InputStreamReader(is,charsetName));
				
				String readline;
				StringBuilder sb = new StringBuilder();
				while((readline=reader.readLine())!=null){
					sb.append(readline+"\n");
				}
				reader.close();
				is.close();
				result = sb.toString().trim();
				Log.i("Net.postURL.result", result);
			}else{
				 result = "NotNet";
			}
		}catch(HttpHostConnectException e){
			Log.i("Net.postURL.Exception", e.toString());
			result = "NotNet";
			return result;
		}catch (Exception e) {
			// TODO Auto-generated catch block
			Log.i("Net.postURL.Exception", e.toString());
			result = "NotNet";
			return result;
		} finally{
			if(reader != null){
				try{
					reader.close();
					return result;
				}catch(IOException e){
					result = "NotNet";
					e.printStackTrace();
				}
			}
		}
		return result;
	}
	
	class AddOperateRecord extends AsyncTask<String, String, String>{

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			activityName = params[0];
			operation = params[1];
			getInfo(activityName,operation);
			return null;
			
		}
		
	}
	public void addOperateRecord(String activityName,String operation){
		
		//new AddOperateRecord().execute(new String[]{activityname,operation});
		this.activityName = activityName;
		this.operation = operation;
		new Thread(runnable).start();
	}
	

  private Runnable runnable = new Runnable(){

	@Override
	public void run() {
		// TODO Auto-generated method stub
		getInfo(activityName,operation);
	}
	  
  };
  
	@SuppressWarnings("deprecation")
	public void getInfo(String activityName,String operation){
		if(MEID == null || MEID.equals("")){
			TelephonyManager tm = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
			android_id = Settings.System.getString(getContentResolver(), Settings.System.ANDROID_ID);
			if(android_id == null) android_id = "";
			MEID = tm.getDeviceId();
			if(MEID == null) MEID = "";
			IMEI = tm.getSubscriberId();
			if(IMEI == null) IMEI = "";
			IMSI = tm.getSimSerialNumber();
			if(IMSI == null) IMSI = "";
			other = "getLine1Number()="+tm.getLine1Number()+",android.os.Build.SERIAL="+android.os.Build.SERIAL;
			if(other == null) other = "";
			PackageManager pm = getPackageManager();
			PackageInfo pi = null;
			try {
				pi = pm.getPackageInfo(getPackageName(), 0);
			} catch (NameNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			location = "";
			versionName = pi.versionName;
			versionCode = pi.versionCode+"";
			osVersion = android.os.Build.VERSION.RELEASE;
			if(osVersion == null) osVersion = "";
			phoneModel = Build.MODEL;
			if(phoneModel == null) phoneModel = "";
		}
		ArrayList<NameValuePair> postparams = new ArrayList<NameValuePair>();
		postparams.add(new BasicNameValuePair("android_id", android_id));
        postparams.add(new BasicNameValuePair("meid", MEID));
        postparams.add(new BasicNameValuePair("imei", IMEI));
        postparams.add(new BasicNameValuePair("imsi", IMSI));
        postparams.add(new BasicNameValuePair("versionName", versionName));
        postparams.add(new BasicNameValuePair("versionCode", versionCode));
        postparams.add(new BasicNameValuePair("osVersion", osVersion));
        postparams.add(new BasicNameValuePair("phoneModel", phoneModel));
        postparams.add(new BasicNameValuePair("location", location));
        postparams.add(new BasicNameValuePair("other", other));
        postparams.add(new BasicNameValuePair("activityName", activityName));
        postparams.add(new BasicNameValuePair("operation", operation));
        //postURL(postparams, "http://119.146.238.100:8081/kqxt/Record", "UTF-8");
	}
	public Bitmap getVerifyCode(String url){
		Log.i("Net.getVerifyCode.url", url);
		Bitmap bitmap = null;
		try {
			HttpClient  client = getHttpClient();
			HttpGet httpget = new HttpGet(url);
			((AbstractHttpClient)client).setCookieStore(cookies);
			HttpResponse response = client.execute(httpget);
			if(response.getStatusLine().getStatusCode() == HttpStatus.SC_OK){
				HttpEntity entity  = response.getEntity();
				cookies = ((AbstractHttpClient)client).getCookieStore();
				InputStream is = entity.getContent();
				bitmap = BitmapFactory.decodeStream(is);
				is.close();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Log.i("Net.postURL.Exception", e.toString());
		} 
		return bitmap;
	}
	
}
