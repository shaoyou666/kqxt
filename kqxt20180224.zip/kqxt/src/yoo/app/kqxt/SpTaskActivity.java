package yoo.app.kqxt;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.TextView;
import android.widget.Toast;

public class SpTaskActivity extends Activity {

	private TextView tv_multichoice,tv_allPass;
	private boolean isMultiChoice = false;
	private CheckBox cb_ycsp_all;
	private ListView lv_ycspRecord,lv_xjspRecord;
	private List<Map<String,Object>> list_ycsp,list_xjsp;
	private SimpleAdapter adapter_xjsp;
	private SpTaskAdapter adapter_ycsp;
	private ProgressDialog pd;
	private Context mContext;
	private String tempUrl;
	private int selected_position;
	private long[] multiChoices;
	private String which_adapter;
	private LinearLayout ll_multiControl;
	private Net net;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		//��title      
	    requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.sptask);
		mContext = SpTaskActivity.this;
		net = (Net)getApplication();
		//net.addOperateRecord("SpTaskActivity","onCreate");
		pd = new ProgressDialog(mContext);
		tv_multichoice = (TextView)findViewById(R.id.tv_multiChoice);
		cb_ycsp_all = (CheckBox)findViewById(R.id.cb_ycsp_all);
		lv_ycspRecord = (ListView)findViewById(R.id.lv_ycspdb);
		lv_xjspRecord = (ListView)findViewById(R.id.lv_xjspdb);
		ll_multiControl = (LinearLayout)findViewById(R.id.ll_multiControl);
		tv_allPass = (TextView)findViewById(R.id.tv_allPass);
		
		list_ycsp = new ArrayList<Map<String,Object>>();
		list_xjsp = new ArrayList<Map<String,Object>>();
		GetListData getListData = new GetListData();
		getListData.execute(new String[0]);
		
		final EditText et_content = new EditText(mContext);
		et_content.setHint(R.string.yj);
		AlertDialog.Builder adbuilder = new AlertDialog.Builder(mContext);
		adbuilder.setTitle("��������");
		adbuilder.setView(et_content);
		adbuilder.setPositiveButton("ͨ��", new DialogInterface.OnClickListener(){

			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				String content = et_content.getText().toString().trim();
				if(content==null || content.equals("")){
					content = "ͨ��";
				}
				String[] pm = {content,"ͨ��","tg1",which_adapter};
				new SpRequest().execute(pm);
			}
			
		});
		adbuilder.setNeutralButton("��ͨ��", new DialogInterface.OnClickListener(){

			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				String content = et_content.getText().toString().trim();
				if(content==null || content.equals("")){
					content = "��ͨ��";
				}
				String[] pm = {content,"��ͨ��","tg2",which_adapter};
				new SpRequest().execute(pm);
			}
			
		});
		adbuilder.setNegativeButton("ȡ��", null);
		final AlertDialog ad = adbuilder.create();
		
		lv_ycspRecord.setOnItemClickListener(new OnItemClickListener(){

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				if(isMultiChoice){
					adapter_ycsp.notifyDataSetChanged();
				}else{
					selected_position = position;
					which_adapter = "yc";
					tempUrl = (String)list_ycsp.get(position).get("sp_url");
					tempUrl = tempUrl.substring(tempUrl.indexOf("?")+1,tempUrl.indexOf("&"));
					tempUrl = "http://119.146.208.70:1080/dk_spwc.asp?"+tempUrl;
					ad.show();	
				}
				
			}
			
		});
		cb_ycsp_all.setOnCheckedChangeListener(new OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton buttonView,
					boolean isChecked) {
				// TODO Auto-generated method stub
				if(isChecked){
					for(int i=0;i<list_ycsp.size();i++){
						lv_ycspRecord.setItemChecked(i, true);
					}
				}else{
					for(int i=0;i<list_ycsp.size();i++){
						lv_ycspRecord.setItemChecked(i, false);
					}
				}
			}
			
		});
		tv_allPass.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				multiChoices = lv_ycspRecord.getCheckedItemIds();
				if(multiChoices.length == 0){
					Toast.makeText(mContext, "û��ѡ�м�¼", Toast.LENGTH_SHORT).show();
				}else{
					new AlertDialog.Builder(mContext).setTitle("ȷ�ϴ���")
					.setMessage("�Ƿ���ѡ�쳣�������봦��Ϊ��ͨ��")
					.setPositiveButton("ȷ�ϴ���", new DialogInterface.OnClickListener() {
						
						@Override
						public void onClick(DialogInterface dialog, int which) {
							// TODO Auto-generated method stub
							which_adapter = "yc";
							String[] pm = {"ͨ��","ͨ��","tg1",which_adapter};
							new PlPassSpRequest().execute(pm);
						}
					}).setNegativeButton("ȡ��", null).show();
				}
			}
			
		});
		
		lv_xjspRecord.setOnItemClickListener(new OnItemClickListener(){

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				selected_position = position;
				which_adapter = "xj";
				tempUrl = (String)list_xjsp.get(position).get("sp_url");
				tempUrl = tempUrl.substring(tempUrl.indexOf("?")+1,tempUrl.indexOf("&"));
				tempUrl = "http://119.146.208.70:1080/spwanc.asp?"+tempUrl;
				ad.show();	
			}
			
		});
		
		tv_multichoice.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(!isMultiChoice){
					tv_multichoice.setText("ȡ����ѡ");
					isMultiChoice = true;
					ll_multiControl.setVisibility(View.VISIBLE);
					lv_ycspRecord.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
					lv_ycspRecord.clearChoices();
				}else{
					tv_multichoice.setText("��ѡ");
					cb_ycsp_all.setChecked(false);
					isMultiChoice = false;
					ll_multiControl.setVisibility(View.GONE);
					lv_ycspRecord.setChoiceMode(ListView.CHOICE_MODE_NONE);
					lv_ycspRecord.clearChoices();
				}
			}
			
		});
	}

	
	public class GetListData extends AsyncTask<String, String, String>{

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			list_ycsp.clear();
			list_xjsp.clear();
			Map<String, Object> map;
			
			String strycsp = net.postURL(null, "http://119.146.208.70:1080/yc_spdb.asp", "UTF-8");
			Document doc_ycsp = Jsoup.parse(strycsp);
			Elements trs_ycsp = doc_ycsp.select("tr");
			for(int i=2;i<trs_ycsp.size();i++){
				Elements tds = trs_ycsp.get(i).select("td");
				if(tds.size()>2){
					map = new HashMap<String, Object>();
					map.put("sp_id", (i-1)+"");
					map.put("sp_name", tds.get(0).text().trim());
					map.put("sp_sp", "����");
					map.put("sp_reason", tds.get(1).text().trim());
					map.put("sp_url", tds.get(2).select("a").attr("href").trim());
					list_ycsp.add(map);
				}
				
			}
			String strxjsp = net.postURL(null, "http://119.146.208.70:1080/xjsp_db.asp", "UTF-8");
			Document doc_xjsp = Jsoup.parse(strxjsp);
			Elements trs_xjsp = doc_xjsp.select("tr");
			for(int i=2;i<trs_xjsp.size();i++){
				Elements tds = trs_xjsp.get(i).select("td");
				if(tds.size()>2){
					map = new HashMap<String, Object>();
					map.put("sp_id", (i-1)+"");
					map.put("sp_name", tds.get(0).text().trim());
					map.put("sp_sp", "����");
					map.put("sp_reason", tds.get(1).text().trim());
					map.put("sp_url", tds.get(2).select("a").attr("href").trim());
					list_xjsp.add(map);
				}
			}
			
			return null;
		}

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			pd.setTitle("��ѯ���������¼");
			pd.setMessage("���ݼ����У����Ժ󡣡���");
			pd.show();
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			pd.dismiss();
			/*
			adapter_ycsp = new SimpleAdapter(mContext,list_ycsp,R.layout.lv_sptask,
					new String[]{"sp_id","sp_name","sp_sp","sp_reason","sp_url"},
					new int[]{R.id.tv_sp_id,R.id.tv_sp_name,R.id.tv_sp_sp,R.id.tv_sp_reason,R.id.tv_sp_url});
			*/
			adapter_ycsp = new SpTaskAdapter(mContext,list_ycsp,lv_ycspRecord);
			lv_ycspRecord.setAdapter(adapter_ycsp);
			
			adapter_xjsp = new SimpleAdapter(mContext,list_xjsp,R.layout.lv_sptask,
					new String[]{"sp_id","sp_name","sp_sp","sp_reason","sp_url"},
					new int[]{R.id.tv_sp_id,R.id.tv_sp_name,R.id.tv_sp_sp,R.id.tv_sp_reason,R.id.tv_sp_url});
			lv_xjspRecord.setAdapter(adapter_xjsp);
			
		}
		
	}
	
	
	public class SpRequest extends AsyncTask<String, String, String>{
		
		private String type;

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			ArrayList<NameValuePair> pp = new ArrayList<NameValuePair>();
	        pp.add(new BasicNameValuePair("TextArea1", params[0]));
	        pp.add(new BasicNameValuePair(params[2],params[1]));
			Net net = (Net)getApplication();
			String postResult = net.postURL(pp, tempUrl ,"UTF-8");
			type = params[3];
			return postResult;
		}

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			pd.setTitle("�ύ����");
			pd.setMessage("���ݼ����У����Ժ󡣡���");
			pd.show();
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			pd.dismiss();
			if(type.equals("yc")){
				list_ycsp.remove(selected_position);
				adapter_ycsp.notifyDataSetChanged();
			}else if(type.equals("xj")){
				list_xjsp.remove(selected_position);
				adapter_xjsp.notifyDataSetChanged();
			}
		}
	}
	public class PlPassSpRequest extends AsyncTask<String, String, String>{

		private ProgressDialog pd;
		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			ArrayList<NameValuePair> pp = new ArrayList<NameValuePair>();
	        pp.add(new BasicNameValuePair("TextArea1", "ͨ��"));
	        pp.add(new BasicNameValuePair(params[2],params[1]));
	        Net net = (Net)getApplication();
	        for(int i=0;i<multiChoices.length;i++){
	        	String url = (String)list_ycsp.get((int) multiChoices[i]).get("sp_url");
	        	url = url.substring(url.indexOf("?")+1,url.indexOf("&"));
	        	url = "http://119.146.208.70:1080/dk_spwc.asp?"+url;
	        	net.postURL(pp, url ,"UTF-8");
	        	publishProgress(i+"/"+multiChoices.length);
	        }
	        
			return null;
		}

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			pd = new ProgressDialog(mContext);
			pd.setTitle("��������");
			pd.setMessage("��ʼ��������...");
			pd.show();
		}

		@Override
		protected void onProgressUpdate(String... values) {
			// TODO Auto-generated method stub
			pd.setMessage("���ڴ�����"+values[0]);
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			pd.dismiss();
			tv_multichoice.setText("��ѡ");
			isMultiChoice = false;
			ll_multiControl.setVisibility(View.GONE);
			lv_ycspRecord.setChoiceMode(ListView.CHOICE_MODE_NONE);
			lv_ycspRecord.clearChoices();
			for(int i=0;i<multiChoices.length;i++){
				list_ycsp.remove((int)multiChoices[i]-i);
			}
			adapter_ycsp.notifyDataSetChanged();
		}
		
	}
	

}
