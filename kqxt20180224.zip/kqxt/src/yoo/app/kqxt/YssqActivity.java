package yoo.app.kqxt;

import java.util.ArrayList;
import java.util.Calendar;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.InputType;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

public class YssqActivity extends Activity implements View.OnTouchListener{
	
	private TabHost th;
	private TextView tv_name,tv_bm,tv_name2,tv_bm2;
	private Spinner sp_lx,sp_startBc,sp_endBc,sp_lx2,sp_bc;
	private EditText et_sDate,et_eDate,et_otherReason,et_sDate2,et_eDate2,et_otherReason2;
	private Context mContext;
	private Net net;
	private String[] str_sp_lx = {"���ݼ�","���","����","��������","�����߷�","����","�����ѵ","����"};
	private String[] str_sp_bc = {"����ϰ�","����°�","�����ϰ�","�����°�"};
	private Button bt_submit,bt_submit2;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		//��title      
	    requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.ysbssq);
		mContext = YssqActivity.this;
		net = (Net)getApplication();
		//net.addOperateRecord("YssqActivity","onCreate");
		findView();
		
		et_sDate.setOnTouchListener(this);
		et_eDate.setOnTouchListener(this);
		et_sDate2.setOnTouchListener(this);
		et_eDate2.setOnTouchListener(this);
		new GetData().execute(new String[]{});
	}

	private void findView() {
		// TODO Auto-generated method stub
		th = (TabHost)findViewById(android.R.id.tabhost);
		th.setup();
		th.addTab(th.newTabSpec("tab1").setIndicator("��ͨԤˢ����").setContent(R.id.tab1));
		th.addTab(th.newTabSpec("tab2").setIndicator("����Ԥˢ����").setContent(R.id.tab2));
		/*
		TabWidget tw = th.getTabWidget();
		for(int i = 0 ; i<tw.getChildCount();i++){
			View v = tw.getChildAt(i);
			final TextView tv = (TextView)v.findViewById(android.R.id.title);
			RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) tv.getLayoutParams();  
			params.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM, 0); //ȡ�����ֵױ߶���  
			params.addRule(RelativeLayout.CENTER_IN_PARENT, RelativeLayout.TRUE); //�������־��ж���  
			//v.getLayoutParams().height = 60;

		}*/
		bt_submit = (Button)findViewById(R.id.bt_submitYssq);
		bt_submit2 = (Button)findViewById(R.id.bt_submitPlyssq);
		tv_name = (TextView)findViewById(R.id.tv_sqr);
		tv_bm = (TextView)findViewById(R.id.tv_bm);
		tv_name2 = (TextView)findViewById(R.id.tv_sqr2);
		tv_bm2 = (TextView)findViewById(R.id.tv_bm2);
		sp_lx = (Spinner)findViewById(R.id.sp_qjlx);
		sp_lx2 = (Spinner)findViewById(R.id.sp_qjlx2);
		sp_startBc = (Spinner)findViewById(R.id.sp_startBc);
		sp_endBc = (Spinner)findViewById(R.id.sp_endBc);
		sp_bc = (Spinner)findViewById(R.id.sp_bc);
		et_sDate = (EditText)findViewById(R.id.et_sDate);
		et_eDate = (EditText)findViewById(R.id.et_eDate);
		et_sDate2 = (EditText)findViewById(R.id.et_sDate2);
		et_eDate2 = (EditText)findViewById(R.id.et_eDate2);
		et_otherReason = (EditText)findViewById(R.id.et_otherreason);
		et_otherReason2 = (EditText)findViewById(R.id.et_otherreason2);
		et_sDate.setHint("�����ȡ����");
		et_eDate.setHint("�����ȡ����");
		et_sDate2.setHint("�����ȡ����");
		et_eDate2.setHint("�����ȡ����");
		
		ArrayAdapter<String> adapter_lx = new ArrayAdapter<String>(mContext,android.R.layout.simple_spinner_item,str_sp_lx);
		sp_lx.setAdapter(adapter_lx);
		sp_lx2.setAdapter(adapter_lx);
		ArrayAdapter<String> adapter_bc = new ArrayAdapter<String>(mContext,android.R.layout.simple_spinner_item,str_sp_bc);
		sp_startBc.setAdapter(adapter_bc);
		sp_endBc.setAdapter(adapter_bc);
		sp_bc.setAdapter(adapter_bc);
		
		sp_lx.setOnItemSelectedListener(new OnItemSelectedListener(){

			@Override
			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				
					if(position == 7 || position == 1){
						et_otherReason.setVisibility(View.VISIBLE);
					}else{
						et_otherReason.setVisibility(View.GONE);
						et_otherReason.setText("");
					}
			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				// TODO Auto-generated method stub
				
			}
			
		});
		sp_lx2.setOnItemSelectedListener(new OnItemSelectedListener(){

			@Override
			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				
					if(position == 7 || position == 1){
						et_otherReason2.setVisibility(View.VISIBLE);
					}else{
						et_otherReason2.setVisibility(View.GONE);
						et_otherReason2.setText("");
					}
			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				// TODO Auto-generated method stub
				
			}
			
		});
		
		bt_submit.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String Sel1 = sp_lx.getSelectedItem().toString();
				String Text1 = et_otherReason.getText().toString();
				String T1 = et_sDate.getText().toString();
				String T2 = et_eDate.getText().toString();
				String banc1 = sp_startBc.getSelectedItem().toString();
				String banc2 = sp_endBc.getSelectedItem().toString();
				if(!Sel1.equals("����") && Text1.equals(""))
					Text1 = "��д��ԭ��";
				if(T1.equals("") || T1 == null || T2.equals("") || T2 == null){
					Toast.makeText(mContext, "��ѡ��ʼ���ڻ�������ڣ�", Toast.LENGTH_SHORT).show();
				}else if(T1.compareTo(T2)>0){
					Toast.makeText(mContext, "�������ڱ������ڿ�ʼ���ڣ�", Toast.LENGTH_SHORT).show();
				}else{
					final String[] params = {Sel1,Text1,T1,T2,banc1,banc2};
					new AlertDialog.Builder(mContext).setTitle("�ύԤˢ����")
					.setMessage("Ԥˢ���룺"+T1+banc1+"��"+T2+banc2+"��Ԥˢԭ��"+Sel1+(Text1.equals("��д��ԭ��")?"":":"+Text1))
					.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
						
						@Override
						public void onClick(DialogInterface dialog, int which) {
							// TODO Auto-generated method stub
							new PostData().execute(params);
						}
					}).setNegativeButton("�����޸�", null).show();
				}
			}
			
		});
		bt_submit2.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String Sel1 = sp_lx2.getSelectedItem().toString();
				String Text1 = et_otherReason2.getText().toString();
				String T1 = et_sDate2.getText().toString();
				String T2 = et_eDate2.getText().toString();
				String banc1 = sp_bc.getSelectedItem().toString();
				if(!Sel1.equals("����") && Text1.equals(""))
					Text1 = "��д��ԭ��";
				if(T1.equals("") || T1 == null || T2.equals("") || T2 == null){
					Toast.makeText(mContext, "��ѡ��ʼ���ڻ�������ڣ�", 0).show();
				}else if(T1.compareTo(T2)>0){
					Toast.makeText(mContext, "�������ڱ������ڿ�ʼ���ڣ�", 0).show();
				}else{
					final String[] params = {Sel1,Text1,T1,T2,banc1};
					new AlertDialog.Builder(mContext).setTitle("�ύԤˢ����")
					.setMessage("Ԥˢ���룺"+T1+"��"+T2+banc1+"��Ԥˢԭ��"+Sel1+(Text1.equals("��д��ԭ��")?"":":"+Text1))
					.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
						
						@Override
						public void onClick(DialogInterface dialog, int which) {
							// TODO Auto-generated method stub
							new PostData2().execute(params);
						}
					}).setNegativeButton("�����޸�", null).show();
				}
			}
			
		});
		
	}

	@Override
	public boolean onTouch(View v, MotionEvent event) {
		// TODO Auto-generated method stub
		if(event.getAction() == MotionEvent.ACTION_DOWN){
			AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
			View view = View.inflate(mContext, R.layout.datepicker_dialog, null);
			final DatePicker dp = (DatePicker)view.findViewById(R.id.datePicker);
			builder.setView(view);
			
			Calendar cal = Calendar.getInstance();
			cal.setTimeInMillis(System.currentTimeMillis());
			dp.init(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH), null);
			
			if(v.getId() == R.id.et_sDate){
				int inType = et_sDate.getInputType();
				et_sDate.setInputType(InputType.TYPE_NULL);
				et_sDate.onTouchEvent(event);
				et_sDate.setInputType(inType);
				et_sDate.setSelection(et_sDate.getText().length());
				
				builder.setTitle("ѡȡ��ʼʱ��");
				builder.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						StringBuffer sb = new StringBuffer();
						sb.append(String.format("%d-%02d-%02d", dp.getYear(),dp.getMonth()+1,dp.getDayOfMonth()));
						et_sDate.setText(sb);
						//et_eDate.requestFocus();
						dialog.cancel();
					}
				});
			}else if(v.getId() == R.id.et_eDate){
				int inType = et_eDate.getInputType();
				et_eDate.setInputType(InputType.TYPE_NULL);
				et_eDate.onTouchEvent(event);
				et_eDate.setInputType(inType);
				et_eDate.setSelection(et_eDate.getText().length());
				
				builder.setTitle("ѡȡ����ʱ��");
				builder.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						StringBuffer sb = new StringBuffer();
						sb.append(String.format("%d-%02d-%02d", dp.getYear(),dp.getMonth()+1,dp.getDayOfMonth()));
						et_eDate.setText(sb);
						dialog.cancel();
					}
				});
			}else if(v.getId() == R.id.et_sDate2){
				int inType = et_sDate2.getInputType();
				et_sDate2.setInputType(InputType.TYPE_NULL);
				et_sDate2.onTouchEvent(event);
				et_sDate2.setInputType(inType);
				et_sDate2.setSelection(et_sDate2.getText().length());
				
				builder.setTitle("ѡȡ��ʼʱ��");
				builder.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						StringBuffer sb = new StringBuffer();
						sb.append(String.format("%d-%02d-%02d", dp.getYear(),dp.getMonth()+1,dp.getDayOfMonth()));
						et_sDate2.setText(sb);
						//et_eDate.requestFocus();
						dialog.cancel();
					}
				}).setNegativeButton("ȡ��", null);
			}else if(v.getId() == R.id.et_eDate2){
				int inType = et_eDate2.getInputType();
				et_eDate2.setInputType(InputType.TYPE_NULL);
				et_eDate2.onTouchEvent(event);
				et_eDate2.setInputType(inType);
				et_eDate2.setSelection(et_eDate2.getText().length());
				
				builder.setTitle("ѡȡ����ʱ��");
				builder.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						StringBuffer sb = new StringBuffer();
						sb.append(String.format("%d-%02d-%02d", dp.getYear(),dp.getMonth()+1,dp.getDayOfMonth()));
						et_eDate2.setText(sb);
						dialog.cancel();
					}
				}).setNegativeButton("ȡ��", null);
			}
			Dialog dialog = builder.create();
			dialog.show();
		}
		return true;
	}
	
	// �����ֻ�����
	/*
	private void hideIM(View edt){
	    try {
	        InputMethodManager im = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
	        IBinder windowToken = edt.getWindowToken();
	        if (windowToken != null) {
	            im.hideSoftInputFromWindow(windowToken, 0);
	        }
	    }
	    catch (Exception e) {
	    	
	    }
	}*/

	public class GetData extends AsyncTask<String, String, String>{

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			Document doc = Jsoup.parse(result);
			Elements tds = doc.select("td");
			if(tds.size()>1){
				tv_name.setText(tds.get(0).text().trim());
				tv_bm.setText(tds.get(1).text().trim());
				tv_name2.setText(tds.get(0).text().trim());
				tv_bm2.setText(tds.get(1).text().trim());
			}
		}

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			String result = net.postURL(null, "http://119.146.208.70:1080/xj_sq.asp","gb2312");
			return result;
		}
		
	}
	public class PostData extends AsyncTask<String, String, String>{

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			/**/
			ArrayList<NameValuePair> postparams = new ArrayList<NameValuePair>();
			postparams.add(new BasicNameValuePair("Sel1", params[0]));
	        postparams.add(new BasicNameValuePair("Text1", params[1]));
	        postparams.add(new BasicNameValuePair("T1", params[2]));
	        postparams.add(new BasicNameValuePair("T2", params[3]));
	        postparams.add(new BasicNameValuePair("banc1", params[4]));
	        postparams.add(new BasicNameValuePair("banc2", params[5]));
	        
			String result = net.postURL(postparams, "http://119.146.208.70:1080/xiujg.asp");
			return result;
		}

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			//final String postResult = result.substring(result.indexOf("(\"")+2,result.indexOf("\")"));
			final String postResult = result;
			new AlertDialog.Builder(mContext).setTitle("������").setMessage(postResult)
			.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					// TODO Auto-generated method stub
					//if(postResult.contains("�ɹ�"))
						finish();
				}
			}).show();
		}
		
	}
	
	public class PostData2 extends AsyncTask<String, String, String>{

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			/**/
			ArrayList<NameValuePair> postparams = new ArrayList<NameValuePair>();
			postparams.add(new BasicNameValuePair("Sel1", params[0]));
	        postparams.add(new BasicNameValuePair("Text1", params[1]));
	        postparams.add(new BasicNameValuePair("T1", params[2]));
	        postparams.add(new BasicNameValuePair("T2", params[3]));
	        postparams.add(new BasicNameValuePair("banc1", params[4]));
	        
			String result = net.postURL(postparams, "http://119.146.208.70:1080/pcyusq_w.asp");
			return result;
		}

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			//final String postResult = result.substring(result.indexOf("(\"")+2,result.indexOf("\")"));
			final String postResult = result;
			new AlertDialog.Builder(mContext).setTitle("������").setMessage(postResult)
			.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					// TODO Auto-generated method stub
					//if(postResult.contains("�ɹ�"))
						finish();
				}
			}).show();
		}
		
	}
}
