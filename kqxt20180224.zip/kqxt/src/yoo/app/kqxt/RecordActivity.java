package yoo.app.kqxt;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;


import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.InputType;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;

public class RecordActivity extends Activity implements View.OnTouchListener {
	
	private EditText et_startDate,et_endDate;
	private Button bt_search;
	private ListView lv_searchResult;
	private List<Map<String, Object>> list;
	private Net net;
	private Context mContext;
	private ProgressDialog pd;
	private String selectedItem,strURL;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		//��title      
	    requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.record);
		mContext = RecordActivity.this;
		et_startDate = (EditText)findViewById(R.id.et_startDate);
		et_endDate = (EditText)findViewById(R.id.et_endDate);
		bt_search = (Button)findViewById(R.id.bt_search);
		lv_searchResult = (ListView)findViewById(R.id.lv_searchResult);
		list = new ArrayList<Map<String, Object>>();
		net = (Net)getApplication();
		//net.addOperateRecord("RecordActivity","onCreate");
		/**/
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date now = new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(now);
		//calendar.add(Calendar.DATE, -1);
		String enDate = sdf.format(calendar.getTime());
		calendar.add(Calendar.DATE, -5);
		String stDate = sdf.format(calendar.getTime());
		
		et_startDate.setText(stDate);
		et_endDate.setText(enDate);
		
		et_startDate.setOnTouchListener(this);
		et_endDate.setOnTouchListener(this);
		bt_search.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String[] dates = {et_startDate.getText().toString(),et_endDate.getText().toString()};
				GetSearchRecord getSearchRecord = new GetSearchRecord();
				getSearchRecord.execute(dates);
			}
			
		});
		
		selectedItem = "���ݼ�";
		final EditText et_other_reason = new EditText(mContext);
		et_other_reason.setVisibility(View.GONE);
		//et_other_reason.setHint(R.string.other_reason);
		et_other_reason.setText("��д��ԭ��");
		final String[] reasonsItem = {"���ݼ�","���","����","��������","�����߷�","����","�����ѵ","����"}; 
		AlertDialog.Builder adbuilder = new AlertDialog.Builder(mContext);
		adbuilder.setTitle("ѡ�񲹴�����ԭ��");
		adbuilder.setSingleChoiceItems(reasonsItem, 0, new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				if(which == 7 || which == 1){
					et_other_reason.setVisibility(View.VISIBLE);
				}else{
					et_other_reason.setVisibility(View.GONE);
					et_other_reason.setText("��д��ԭ��");
				}
				selectedItem = reasonsItem[which];
			}
		});
		adbuilder.setView(et_other_reason);
		adbuilder.setPositiveButton("�ύ", new DialogInterface.OnClickListener(){

			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				String other_reason = et_other_reason.getText().toString().trim();
				String[] postParams = {selectedItem,other_reason}; 
				new PostYcRequest().execute(postParams);
			}
			
		});
		adbuilder.setNegativeButton("ȡ��", null);
		final AlertDialog ad = adbuilder.create();
		
		lv_searchResult.setOnItemClickListener(new OnItemClickListener(){

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				strURL = list.get(position).get("url").toString();
				if(strURL != null && !strURL.equals("")){
					strURL = strURL.substring(strURL.indexOf("?")+1);
					//tempUrl = tempUrl.replace(" ", "%20");
					strURL = "http://119.146.208.70:1080/yic.asp?"+strURL;
					ad.show();	
				}
				/**/
			}
			
		});
		
		
	}
	
	public class GetSearchRecord extends AsyncTask<String, String, String>{

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			ArrayList<NameValuePair> postparams = new ArrayList<NameValuePair>();
	        postparams.add(new BasicNameValuePair("T1", params[0]));
	        postparams.add(new BasicNameValuePair("T2", params[1]));
	        
	        String result = net.postURL(postparams, LoginActivity.homeURL + "grdkck1.asp");
	        Document doc = Jsoup.parse(result);
	        String hash = doc.select("input").get(0).val();
	        postparams.add(new BasicNameValuePair("hash", hash));
	        
			String postresult = net.postURL(postparams, LoginActivity.homeURL + "grdkck1.asp?action=1");
			postresult.replace("&nbsp", "");
			return postresult;
		}

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			pd = new ProgressDialog(mContext);
			pd.setTitle("��ѯ�򿨼�¼");
			pd.setMessage("���ڲ�ѯ�����Ժ󡣡���");
			pd.show();
		}

		@SuppressWarnings("null")
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			pd.dismiss();
			list.clear();
			Map<String, Object> map = null;
			Document doc = Jsoup.parse(result);
			Elements trs = doc.getElementsByClass("shezhi").select("tr");
			if(trs != null || trs.size()>0){
				String[] bcs = {"����ϰ�","����°�","�����ϰ�","�����°�","ҹ���ϰ�","ҹ���°�"};
				for(int i=2;i<trs.size();i++){
					
					Elements tds = trs.get(i).select("td");
					for(int j=0;j<tds.size()/2;j++){
						map = new HashMap<String, Object>();
						String d = tds.get(0).text().trim().replace("&nbsp", "");
						map.put("date", d+"\n"+getWeek(d));
						map.put("bc", bcs[j]);
						map.put("dksj", tds.get(j*2+2).text().trim().replace("&nbsp", ""));
						map.put("status", tds.get(j*2+1).text().trim().replace("&nbsp", ""));
						map.put("url", tds.get(j*2+1).select("a").attr("href").trim());
						list.add(map);
					}
					
				}
			}else{
				map = new HashMap<String, Object>();
				map.put("date", "�޼�¼");
				map.put("bc", "�޼�¼");
				map.put("dksj", "�޼�¼");
				map.put("status", "�޼�¼");
				list.add(map);
			}
			
			MSimpleAdapter adapter = new MSimpleAdapter(mContext,list,R.layout.lv_searchrecord,
					new String[] {"date","bc","dksj","status"},
					new int[]{R.id.tv_date,R.id.tv_bc,R.id.tv_dksj,R.id.tv_status});
			lv_searchResult.setAdapter(adapter);
		}
		
	}
	
	public String getWeek(String sDate){
		String week = "";
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		Calendar c = Calendar.getInstance();
		try{
			c.setTime(sdf.parse(sDate));
		}catch(Exception e){
			e.printStackTrace();
		}
		switch(c.get(Calendar.DAY_OF_WEEK)){
		case 1:
			week += "������";
			break;
		case 2:
			week += "����һ";
			break;
		case 3:
			week += "���ڶ�";
			break;
		case 4:
			week += "������";
			break;
		case 5:
			week += "������";
			break;
		case 6:
			week += "������";
			break;
		case 7:
			week += "������";
			break;
		}
		return week;
	}
	
	
	public class PostYcRequest extends AsyncTask<String, String, String>{

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			String s1 = strURL.substring(strURL.indexOf("bc_sm=")+6,strURL.indexOf("&"));
			String s2 = strURL.substring(strURL.indexOf("&sj_t=")+6);
			ArrayList<NameValuePair> pp = new ArrayList<NameValuePair>();
	        pp.add(new BasicNameValuePair("Sel1", params[0]));
	        pp.add(new BasicNameValuePair("Text1",params[1]));
	        pp.add(new BasicNameValuePair("bc_sm",s1));
	        pp.add(new BasicNameValuePair("sj_t",s2));
	        strURL = strURL.substring(0,strURL.indexOf("?"));
			Net net = (Net)getApplication();
			//Log.i("PostYcRequest", "Sel1="+params[0]+",Text1="+params[1]+",bc_sm="+s1+",sj_t="+s2);
			String postResult = net.postURL(pp, strURL, "gb2312");
			//Log.i("PostYcRequest_postResult", postResult);
			return postResult;
		}

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			pd.setCancelable(false);
			pd.setTitle("�ύԤˢ����");
			pd.setMessage("���ݼ����У����Ժ󡣡���");
			pd.show();
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			pd.dismiss();
			Document doc = Jsoup.parse(result);
			Elements tds = doc.select("td");
			if(tds.size()>0){
				String str = tds.get(0).text().trim();
				new AlertDialog.Builder(mContext).setTitle(str)
				.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						String[] dates = {et_startDate.getText().toString(),et_endDate.getText().toString()};
						new GetSearchRecord().execute(dates);
					}
				}).show();
			}else{
				String[] dates = {et_startDate.getText().toString(),et_endDate.getText().toString()};
				new GetSearchRecord().execute(dates);
			}
		}
	}

	@Override
	public boolean onTouch(View v, MotionEvent event) {
		// TODO Auto-generated method stub
		if(event.getAction() == MotionEvent.ACTION_DOWN){
			AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
			View view = View.inflate(mContext, R.layout.datepicker_dialog, null);
			final DatePicker dp = (DatePicker)view.findViewById(R.id.datePicker);
			builder.setView(view);
			
			Calendar cal = Calendar.getInstance();
			cal.setTimeInMillis(System.currentTimeMillis());
			dp.init(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH), null);
			
			if(v.getId() == R.id.et_startDate){
				int inType = et_startDate.getInputType();
				et_startDate.setInputType(InputType.TYPE_NULL);
				et_startDate.onTouchEvent(event);
				et_startDate.setInputType(inType);
				et_startDate.setSelection(et_startDate.getText().length());
				
				builder.setTitle("ѡȡ��ʼʱ��");
				builder.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						StringBuffer sb = new StringBuffer();
						sb.append(String.format("%d-%02d-%02d", dp.getYear(),dp.getMonth()+1,dp.getDayOfMonth()));
						et_startDate.setText(sb);
						//et_eDate.requestFocus();
						dialog.cancel();
					}
				}).setNegativeButton("ȡ��", null);
			}else if(v.getId() == R.id.et_endDate){
				int inType = et_endDate.getInputType();
				et_endDate.setInputType(InputType.TYPE_NULL);
				et_endDate.onTouchEvent(event);
				et_endDate.setInputType(inType);
				et_endDate.setSelection(et_endDate.getText().length());
				
				builder.setTitle("ѡȡ����ʱ��");
				builder.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						StringBuffer sb = new StringBuffer();
						sb.append(String.format("%d-%02d-%02d", dp.getYear(),dp.getMonth()+1,dp.getDayOfMonth()));
						et_endDate.setText(sb);
						dialog.cancel();
					}
				}).setNegativeButton("ȡ��", null);
			}
			Dialog dialog = builder.create();
			dialog.show();
		}
		return true;
	}

}
